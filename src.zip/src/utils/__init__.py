"""
Utilities for the skin cancer classification project.
"""