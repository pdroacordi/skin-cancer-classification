"""
Pipelines for the skin cancer classification project.
"""