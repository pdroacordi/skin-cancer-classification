"""
Skin cancer classification project.
"""